#' Test fucntion
#' 
#' @param x: value to square
#' @return Square of function

test<-function(x){
  return(x^2)
}
