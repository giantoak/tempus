install.packages(c('plyr','reshape2','Quandl','MASS','MatchIt','TSA'), repos='http://cran.rstudio.com/', lib='/usr/lib/opencpu/library/')
# Haven't tested this command
